<?php

return [
    'adminEmail' => 'admin@example.com',	
	'FileDirectory' =>  dirname(__DIR__) . '/content',	
	'ImageDirectory' =>  dirname(__DIR__) . '/web/content',		
	'ImageDirectoryAddress' =>  '/content',	
	'projectName' => 'k-means',
	'companyName' => 'k-means',	
	'user.passwordResetTokenExpire' => 60*15,
	'user.activationTokenExpire' => 60*60*24,	
	'supportEmail' => 'admin@example.com',
	'' => '',
	'' => '',
	'' => '',
	'' => '',
];
