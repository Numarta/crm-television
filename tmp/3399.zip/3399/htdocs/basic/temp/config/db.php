<?php


return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=base2928',
    'username' => 'root',
    'password' => '1p2o3w4',
    'charset' => 'utf8',	
];

/*
return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=u429579.mysql.masterhost.ru;dbname=u429579_2912',
    'username' => 'u429579_aleksey',
    'password' => '_a-2strUpYcH9L',
    'charset' => 'utf8',	
];
*/