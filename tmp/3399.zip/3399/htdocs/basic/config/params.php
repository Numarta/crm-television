<?php

return [
    'adminEmail' => 'admin@example.com',	
	'FileDirectory' =>  dirname(__DIR__) . '/content',	
	
	
	'ContentDirectory' =>  '@app/content',
	
	
	'ImageDirectory' =>  dirname(__DIR__) . '/web/content/image',
	'ImageDirectoryAddress' =>  '/content/image',	
	
	'ThumbImageDirectory' =>  dirname(__DIR__) . '/web/content/thumb',
	'ThumbImageDirectoryAddress' =>  '/content/thumb',	
	
	'projectName' => 'Типография',
	'companyName' => 'Типография',	
	'user.passwordResetTokenExpire' => 60*15,
	'user.activationTokenExpire' => 60*60*24,	
	'supportEmail' => 'admin@example.com',
	
	'' => '',
	'' => '',
	'' => '',
	'' => '',
];
